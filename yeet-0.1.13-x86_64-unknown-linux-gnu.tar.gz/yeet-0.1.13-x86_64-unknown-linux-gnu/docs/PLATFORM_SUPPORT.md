# Platform support

Yeet treats macOS, Linux, and Windows as native desktop/server targets. Platform support is gated in CI rather than inferred from conditional compilation.

## Supported tiers

| Platform | Architecture | CI level | Shell sandbox | Local IPC | Release artifact |
| --- | --- | --- | --- | --- | --- |
| macOS | arm64 | Full | sandbox-exec | Unix socket | `.tar.gz` |
| macOS | x86_64 | Release build | sandbox-exec | Unix socket | `.tar.gz` |
| Linux | x86_64 | Full | Landlock via `nono` | Unix socket | `.tar.gz`, `.deb` |
| Linux | arm64 | Full native | Landlock via `nono` | Unix socket | `.tar.gz`, `.deb` |
| Linux | i686 (32-bit x86) | Release build + smoke | Unavailable (fails closed) | Unix socket | `.tar.gz`, `.deb` (i386) |
| Windows | x86_64 | Full | AppContainer via `io-harness` | authenticated loopback TCP | `.zip` |
| Windows | arm64 | Full native | AppContainer via `io-harness` | authenticated loopback TCP | `.zip` |

`Full` means Rust format/check/test/Clippy, RuntimeSource build/tests, CLI/runtime smoke, and release builds are expected to pass on that target. Linux and Windows also execute native sandbox smoke tests. Remote WebUI builds on all primary desktop OSes; browser E2E runs on Linux.

## Configuration and state

`YEET_CONFIG_DIR` always wins when set. Existing `~/.yeet` installations remain in place after upgrade so a user never silently splits state between the Rust host and RuntimeSource. New clean installations use:

- macOS: `~/.yeet` for compatibility with existing Yeet/Codex workflows.
- Linux: `$XDG_CONFIG_HOME/yeet`, falling back to `~/.config/yeet`.
- Windows: the roaming application-data directory under `Yeet`.

Sensitive directories and files are hardened to user-private permissions. Unix uses restrictive mode bits. Windows removes inherited ACL entries and grants full control to the current user, SYSTEM, and local Administrators. Windows local daemon endpoint files receive the same protection and carry a per-listener random authentication token.

## Shell contract

`run_shell` is a non-interactive automation command runner, not an interactive terminal emulator. It captures stdout/stderr and does not promise PTY/ConPTY semantics. Shells are auto-discovered with a clean, non-interactive invocation: Bash (Git Bash on Windows), then the platform PowerShell, then `cmd.exe` on Windows. Explicit `shell: bash | zsh | sh | powershell | cmd` overrides are validated against discovery.

Windows launches quote per shell: cmd receives its script verbatim inside one quote pair that `cmd /S` strips positionally, and PowerShell scripts travel as `-EncodedCommand`, so embedded quotes and Unicode survive both `powershell.exe` and `pwsh.exe` command-line parsing. cmd output is forced to UTF-8 with `chcp 65001` and PowerShell sets UTF-8 console encodings, so Unicode output decodes instead of being mangled by legacy code pages; BOM-marked UTF-16 output (for example `wmic` and `reg query`) is detected and decoded. Direct executable/argument-array execution resolves executables through PATH + PATHEXT and refuses the batch files it finds with an explicit error, since cmd re-expands batch arguments unsafely.

Output is spooled while the command runs. Each command writes a bounded on-disk transcript (64 MiB per command, 512 MiB per session) that is exposed as an artifact, so output beyond the in-memory capture window remains readable through `read_artifact`/`search_artifact`. A foreground command that outlives `yieldSeconds` (default 120) keeps running as a shell job and returns its `jobId` instead of being killed; `timeoutSeconds` is a hard deadline and background jobs default to four hours. On Unix, pipe readers are nonblocking, so cancellation and sandbox deadlines still take effect when a descendant keeps a pipe open.

Sandboxed commands are fail-closed. Linux uses Landlock through `nono`; Windows uses an AppContainer helper. Sandboxed execution denies network access by default. An unsupported network allowlist or secret-injection request is rejected rather than silently widening permissions.

## Process and daemon lifecycle

Unix background daemons are detached into their own session/process group and tree shutdown attempts SIGTERM before SIGKILL. Windows child processes join a Job Object with kill-on-close, so descendants cannot escape cleanup and orphans are reaped even when the leader has already exited or Yeet dies. Termination attempts a console break and a non-forced `taskkill` tree request first, then escalates to `TerminateJobObject` (or `taskkill /T /F` when no job object could be assigned); process-tree discovery is never required for forced cleanup.

Unix local control channels use filesystem Unix-domain sockets. Windows uses `127.0.0.1` with a random per-listener bearer token stored in the private endpoint file. An unauthenticated process that only discovers the TCP port cannot issue local daemon commands.

## Browser authentication

Browser OAuth uses the platform-native launcher with fallbacks:

- macOS: `open`.
- Windows: Explorer, then PowerShell `Start-Process`.
- WSL: `wslview`, Windows Explorer, then `xdg-open`.
- Linux desktop: `xdg-open`, then `gio open`.

### Headless / SSH login

Run `yeet auth login codex-cli --no-browser` (also supported for `openai`,
`gemini` / `gemini-web`, `openrouter`, and `mistral`). SSH sessions automatically
use this mode. Yeet prints the sign-in URL immediately, without trying to launch
an application on the server, and waits for approval. A browser is still needed
on another machine; this is not unattended password-based login.

For Codex, Gemini and OpenRouter, OAuth redirects to a loopback listener **on
the server**. Opening the URL on your laptop alone is not sufficient. Yeet prints
the actual callback port and a tunnel command:

```sh
# In the remote SSH shell:
yeet auth login codex-cli --no-browser

# In a separate terminal on your laptop, using the port Yeet prints:
ssh -N -L PORT:127.0.0.1:PORT USER@HOST
```

Keep both commands running, then open the printed sign-in URL on your laptop.
The tunnel forwards the browser's localhost callback to Yeet. The listener stays
bound to `127.0.0.1`; do not expose it on a public interface. If the local port is
occupied, use the manual alternative instead.

**Without port forwarding:** complete sign-in locally, copy the full localhost
redirect URL from the browser address bar (the page may fail to load), and run
`curl --noproxy '*' 'FULL_REDIRECT_URL'` in a second SSH shell on the server while
the original login is still waiting. Quote the URL so its query parameters are
preserved. The original flow still checks state and PKCE. Treat this URL as a
secret: do not share it or save it in shell history. If login times out, start a
new login and use its new URL; old callbacks cannot complete a new attempt.

Mistral polls for approval and needs no loopback tunnel. Claude authentication is
delegated to Claude Code: run `claude auth login` on the server or supply
`CLAUDE_CODE_OAUTH_TOKEN`. Antigravity requires its local application and does not
support headless browser login. `--no-browser` reports these limitations instead
of silently launching a desktop app.

When a desktop browser opener is unavailable, the runtime also falls back to a
manual URL diagnostic. Use the explicit CLI headless flow above over SSH so that
the URL is delivered as interactive output rather than captured bridge stderr.

## Computer Use

Yeet's built-in Computer Use uses the independent [Open Computer Use](https://github.com/iFurySt/open-computer-use) npm package, installed with `yeet install computer-use` under the Yeet state directory (`YEET_CONFIG_DIR` overrides it). It starts the package’s persistent JavaScript MCP adapter with Yeet’s Node executable; Codex and its private plugins are not required. The package selects the macOS, Linux, or Windows native runtime. macOS requires 14+ and Accessibility/Screen Recording grants; Linux and Windows require a usable logged-in desktop session. Missing or incomplete installations report `yeet install computer-use`. It does not silently substitute browser automation.

## Releases and integrity

Linux i686 requires a separately supplied compatible Node.js 20+ installation. The current `nono` sandbox backend supports only x86_64 and aarch64: i686 reports sandboxing as unavailable and refuses sandboxed shell commands. Unrestricted shell execution requires the user's explicit `yeet sandbox mode unlimited` opt-in.

Tag pushes matching `v*` first verify that the tag matches the synchronized Cargo, RuntimeSource, and WebUI package versions, then run the focused release checks. Release artifacts are built on native macOS arm64/x64, Linux arm64/x64, and Windows arm64/x64 runners, plus Linux i686 using the x64 runner's multilib toolchain; Linux i686 binaries are smoke-tested on that runner before upload. Each staged archive must report the expected version and pass `yeet doctor` against its bundled runtime before upload. Unix packaging additionally smoke-tests the bundled installer into a temporary prefix. Each package gets a SHA-256 sidecar and the release gets an aggregate `SHA256SUMS`. GitHub build-provenance attestations are emitted for release artifacts. Windows Authenticode signing is enabled automatically when the release environment provides `WINDOWS_SIGN_CERTIFICATE_BASE64` and `WINDOWS_SIGN_CERTIFICATE_PASSWORD`; unsigned development releases remain possible when no certificate is configured.

Extracted Unix archives include `install.sh`, which requires Node.js 20 or newer and installs the prebuilt binary plus bundled runtime without a Rust toolchain. The Windows release zip carries the same `bin\yeet.exe` plus `share\yeet\runtime` layout; `install.ps1` installs it into a user prefix (no administrator rights), verifies the release SHA-256 before installing, and can also build from source with `-Build`. Linux CI additionally creates Debian packages when `dpkg-deb` is available. Published macOS/Linux checksums are also used to render the Homebrew formula for the external tap.

## Linux containers

The supported Docker image uses Debian Bookworm with Node.js 22, runs Yeet as a non-root user, and places `tini -g` at PID 1 so Unix stop signals reach the Yeet child process group while orphaned children are reaped. The image also supplies a UTF-8 locale and a conservative `xterm-256color` terminal default for interactive TUI sessions. `YEET_RUNTIME_DIR` and `YEET_CONFIG_DIR` are explicit rather than depending on desktop-specific directory discovery.

Yeet-owned background runtimes, provider bridges, and extensions are placed in dedicated Unix process groups. Forced cleanup captures the descendant tree before signaling and terminates each Yeet-owned process or process group, so a child that creates its own group is not left behind when a supervisor is recycled. On Linux, descendant discovery reads `/proc` directly rather than depending on `ps`; a compatibility `ps` path remains for other Unix platforms.

Landlock is a host-kernel capability, so some Docker Desktop/VM kernels do not expose it even though the image itself is Linux. `yeet doctor` reports the detected Landlock ABI or an explicit unavailable/fail-closed status. When Landlock is unavailable, sandboxed shell execution remains disabled rather than falling back to unrestricted execution. A user who deliberately accepts the container itself as the security boundary can opt in to unrestricted shell execution with `yeet sandbox mode unlimited`; Yeet never enables that downgrade automatically.

The TUI requires both stdin and stdout to be terminals. In Docker, use `-it`; non-interactive invocations fail before background/TUI setup with an actionable diagnostic. Long-lived container services should use `yeet mcpserver run` so the MCP server remains in the foreground and participates in the container lifecycle. Wildcard binds such as `0.0.0.0` require an explicit `--public-url` because Yeet cannot infer the externally reachable MCP URL from a container bind address; for local port publishing use `--public-url http://localhost:7332/mcp`, and use the real HTTPS endpoint for remote exposure. Managed `mcpserver start` remains useful on normal Linux hosts but is not the recommended one-shot-container lifecycle.

`Scripts/test-linux-container.sh` builds the production image and verifies the packaged Node bridge with `yeet doctor`, non-root/config writes, collision-safe UID/GID remapping, named-volume config persistence, operation with a read-only image filesystem plus writable config/tmp/workspace mounts, deterministic no-TTY failure, and the real direct-entrypoint foreground HTTP MCP server through its `/health` endpoint plus clean `docker stop` handling. It also exercises the packaged Linux Landlock helper: supported kernels must enforce a read-only grant, while kernels without Landlock must fail closed with the documented diagnostic. CI runs this smoke on Ubuntu so container packaging and Linux isolation behavior are continuously checked in addition to native Linux tests.

## Support boundaries

Node.js 20 or newer remains a runtime requirement. Yeet's CI uses Node.js 22. Platform-native sandbox behavior is tested on current GitHub-hosted OS images; older kernels or Windows builds that lack the required OS isolation primitives are expected to fail closed rather than run model shell commands unrestricted.
