# Changelog

## [Unreleased]

## [0.1.13] - 2026-11-16

- Avoid Claude thinking-signature failures after tool or conversation changes, including when thinking is off.
- Keep the Remote WebUI responsive in long sessions: only the newest 120 transcript rows are mounted (older rows load on request), unchanged rows are not re-rendered while a reply streams, and the activity spinner no longer drives view updates.
- Simplify the Remote WebUI: a flatter workspace panel that lists only status you act on, a single-row composer, full-width tool-call details, one corner scale and sentence-case labels.
- Fix the Remote WebUI losing follow-output when a transcript is replaced.

## [0.1.12] - 2026-11-16

- Fix Claude thinking replay when thinking is disabled.
- Fix Codex discovery on Linux and bound provider model requests and streaming completion.
- Publish each platform's release package as soon as its GitHub Actions build finishes.

## [0.1.11] - 2026-11-12

- Include the prebuilt compatibility Remote WebUI in release binaries on macOS, Linux, and Windows; no frontend build is required for binary installs.
- Show headerless, chronological tool calls in the TUI and Remote WebUI, and remove duplicate latest-tool failure activity.
- Fix Gemini tool-result turns, model discovery, and streaming failures; honor provider retry policy instead of retrying exhausted quota.
- Recover from Anthropic thinking-binding mismatches after tool discovery.
- Fix the Remote spinner center and remove redundant explanatory UI copy.
- Add a host-side Terminal-Bench runner using a Rosetta Docker-in-Docker daemon and dataset overrides for 2.1 runs.

## [0.1.10] - 2026-11-12

- Add Linux i686 (32-bit x86) release archives, i386 Debian packages, and installer architecture detection; report the unsupported 32-bit sandbox and fail closed unless unrestricted execution is explicitly enabled.
- Isolate Remote connections and reconcile streams without frame queues; resolve composer uploads before accepting submissions.
- Preserve session-management input across rerenders, isolate drafts, and restore authentication recovery.
- Load directory instructions before the first mutation and check instructions for move destinations.
- Fix dropped uppercase F key events in Remote and a UTF-8 truncation panic in MCP trace lists.
- Apply frontend dependency security fixes and clarify active versus historical browser test contracts.

## [0.1.9] - 2026-11-11

- Add the EXAONE API provider to the runtime and report its rate limits as provider usage.
- Render semantic tool details in the Remote workbench, with a literal, readable fallback for structured tools that only offer raw inspection.
- Refine the remote workbench and conversation surfaces: work-history organization, transcript update isolation, shell and workspace panel improvements, brand and navigation icon polish, and spacing and motion.
- Fix remote composer and mobile layout issues, preserve the embedded terminal across UI updates, and follow Safari document and visual-viewport scrolling.
- Connect remote settings, tasks, debate, agents and session management, harden task saves, and apply server themes with verified feature persistence; coalesce runtime snapshots and avoid settings lock stalls.
- Accept terminal line feeds as composer newlines in the TUI and avoid a UTF-8 panic in text-edit line mapping.

## [0.1.8] - 2026-11-07

- Add headless provider OAuth login with `--no-browser`, automatic SSH detection, and callback forwarding instructions.
- Add scheduled agent tasks with persistent background execution and a terminal task manager, including one-time, interval, and quota-reset schedules.
- Harden task editing, scheduler failover, running-session reservations, and task-state preservation across resets.
- Add the Mistral Vibe API provider, browser sign-in, and plan usage reporting.
- Remove the unsupported native desktop host and local GUI bridge; retain the existing Remote protocol and web compatibility client.

## [0.1.7] - 2026-11-04

- Add private native memory storage, opt-in session episodes, scoped shared recall, and offline hybrid search with managed CPU embeddings.
- Add a local TUI memory manager through settings and memory commands.
- Add MCP CLI OAuth and bearer-token login.
- Improve shell and file-edit reliability, whitespace-tolerant replacements, and ancestor instruction handling.
- Preserve goal history and resume interrupted context rollover.
- Improve TUI response selection, clipboard shortcuts, and default text contrast.
- Remove duplicate Anthropic and Gemini Web provider registrations.

## [0.1.6] - 2026-10-30

- Harden opt-in Remote: enforce browser Origin checks, throttle bad access keys, bind to loopback by default, and refuse unauthenticated non-loopback binds.
- Harden the MCP HTTP server: reject cross-origin browser requests, cap OAuth client registrations, and throttle authorization-key attempts.
- Permission prompts now offer allow once or allow for session; session approvals are saved with the session.
- Disabled tools, Skills, and MCP servers now ask for permission instead of failing the model's request.
- Offer to install the Computer Use runtime when the model requests it and it is missing.
- Split web search installer and result normalization into separate modules.

## [0.1.5] - 2026-10-30

- Stabilize terminal redraw verification during asynchronous Git refresh.

## [0.1.4] - 2026-10-30

- Add lightweight native web search and improve search configuration.
- Improve Linux shell handling and headless permission prompts.
- Improve Windows terminal input and suppress background console windows.
- Update web dependencies.

## [0.1.3] - 2026-10-26

- Add richer tool detail views for file edits, shell commands, and file reads, with explicit lifecycle status.
- Add TUI session management with rename, workspace moves, safe deletion, and Vim-style navigation and search.
- Stream shell output to paged disk transcripts and hand foreground timeouts off to background jobs.
- Improve shell timeout handling, output diagnostics, and working-directory accounting.
- Fix cold provider bridge startup and gaps in multiline TUI message backgrounds.

## [0.1.2] - 2026-10-23

- Improve TUI and Remote workbench navigation, tool displays, reasoning visibility, and rendering responsiveness.
- Preserve conversation context and current-run progress across context rollover.
- Improve file editing reliability, shell working-directory persistence, and tool output handling.
- Add main-agent user questions and improve goal-mode controls and blocked-goal handling.
- Improve provider compatibility, session persistence recovery, and shared Remote/TUI runtime behavior.

## [0.1.1] - 2026-10-09

- Improve agent group orchestration, task lifecycle handling, and agent controls.
- Improve TUI and WebUI workspace, session, composer, and activity behavior.
- Improve provider authentication and OpenAI reasoning compatibility.
- Improve installer replacement lifecycle handling.

## [0.1.0] - 2026-09-15

- Native Rust CLI/TUI with TypeScript provider runtime.
- Remote WebUI, MCP server, Skyline, extensions, and computer-use integration.
- OpenAI, Codex CLI, Claude, Gemini, OpenRouter, OpenCode, and custom OpenAI-compatible providers.
- macOS, Linux, and Windows releases for ARM64 and x64.
- Self-update support with SHA-256 verification.
- Docker support and release provenance attestations.
